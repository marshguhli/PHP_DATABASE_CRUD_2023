<?php
include_once ('conn.php');
$db= new Conn();
?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Book</title>
</head>
<body>
<?php
$id=$_GET['id'];
$qry = "SELECT * FROM book WHERE book_id = $id";
$run =$db -> select($qry);
foreach ($run as $row) {
        $username =$row['name'];
        $published =$row['publicing_year'];
        $author =$row['author_id'];}
echo'<a href="index.php">Back</a>';
echo'</form>';
echo'<form action="" method="post">';
echo'<label for="">Name</label>';
echo'<input type="text" name="name" value="'.$username.'"><label for="">Published</label>';
echo'<input type="text" name="publicing_year" value="'.$published.'"><label for="">Author</label>';
echo'<select name="author_id" class="form-control">';
echo'<option value="'.$author.'">-</option><option value="-">';         
$query = "SELECT author_id, full_name FROM author";
$run =$db -> select($query);
foreach ($run as $row) {
    $username=$row['full_name'];
    echo "<option>".$row['author_id']."</option>";
}
echo'</option></select>';
echo'<br><br>';
echo'<input type="submit" name="update" value ="update">';
echo'</form>';
if(isset($_POST['update'])){
    $name = $_POST['name'];
    $published = $_POST['publicing_year'];
    $author = $_POST['author_id'];
    return $db->update_book($name, $published, $id, $author);
}
?>
</body>
</html>
