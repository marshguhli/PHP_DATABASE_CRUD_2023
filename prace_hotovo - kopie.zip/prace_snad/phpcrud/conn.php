<?php
class Conn{
    
    private ?mysqli $db;
    public function __construct()
    {
        $db = mysqli_connect("localhost","root", "", "library");
        $this->db = $db;
    }
    
    function select(string $query): array
    {
        $result = mysqli_query($this->db, $query);
        if ($result == false) {
            return [];
        }
        $output = [];
        while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
            $output[] = $row;
        }
        return $output;
    }
    function insert_author(string $table, $name): bool
    {
        return (bool) mysqli_query(
            $this->db,
            $qry = "INSERT INTO author (full_name) VALUES ('$name')",
            header('location: index.php')
        );
    }
    function update_author(string $table, int $id,  $name): bool
    {
        return (bool) mysqli_query(
            $this->db,
            "UPDATE `$table` SET full_name='$name' WHERE author_id = $id",
            header('location: index.php')
        );
    }

    function delete_author(int $id): bool{   
        return (bool) mysqli_query(
            $this->db,
            "DELETE FROM author WHERE author_id = $id",
            header('location: index.php')
           
        ); 
    }
    function insert_book($name,$published,$author): bool
    {
        return (bool) mysqli_query(
            $this->db,
            $qry = "INSERT INTO book (name, publicing_year, author_id) VALUES ('$name','$published','$author')",
            header('location: index.php')
        );
    }
    function update_book($name, $published, int $id, $author): bool
    {
        return (bool) mysqli_query(
            $this->db,
            "UPDATE book SET name='$name', publicing_year='$published', author_id='$author' WHERE book_id=$id",
            header('location: index.php')
        );
    }
    function delete_book(int $id): bool{   
        return (bool) mysqli_query(
            $this->db,
            "DELETE FROM book WHERE book_id = $id",
            header('location: index.php')
           
        ); 
    }

}



?>