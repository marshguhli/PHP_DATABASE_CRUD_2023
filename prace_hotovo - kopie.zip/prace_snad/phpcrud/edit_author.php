<?php
include_once ('conn.php');
$db= new Conn();
$id=$_GET['id'];
$qry = "SELECT * FROM author WHERE author_id = $id";
$run =$db -> select($qry);
    foreach ($run as $row) {
        $username=$row['full_name'];
}
?>
<!DOCTYPE html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Author</title>
</head>
<?php
echo '<a href="index.php">Back</a>';
echo '<form action="" method="post">';
echo '<label for="">Name</label>';
echo '<input type="text" name="name" value="';
echo $username; echo'">';
echo '<br><br>';
echo '<input type="submit" name="update" value ="update">';
echo '</form>';
if(isset($_POST['update'])){
    $name = $_POST['name'];
    return $db->update_author('author', $id, $name);
}   
?>
</html>
