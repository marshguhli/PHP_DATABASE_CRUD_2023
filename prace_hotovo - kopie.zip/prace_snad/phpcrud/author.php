<?php
include_once ('conn.php');
$db= new Conn();
?>
<!DOCTYPE html>
<html>
<html lang="cs">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP CRUD</title>
    </head>
    <body>
    <?php
echo '<a href="index.php">Back</a>';
echo '<form action="" method="post">';
echo '<label for="">Name</label>';
echo '<input type="text" name="name" placeholder="Enter first and last name">';
echo '<input type="submit" name="submit" value ="submit">';
echo '</form>';
if(isset($_POST["submit"])){
    $name = $_POST["name"];
    $run= $db ->insert_author('author', $name);
}
?>
    </body>
</html>
