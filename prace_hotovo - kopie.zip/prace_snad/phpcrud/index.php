<?php
include_once('conn.php');
$db = new Conn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    //select s buttony - author
echo '<td><a href="book.php">Add Book</a>';
echo '<a href="author.php">Add Author</a>';
echo '<h3>Listing of Authors</h3>';
echo '<table>';
echo '<tr><th>N.</th>';
echo '<th>a_id</th>';
echo '<th>Author Name</th>';
echo '<th>Books</th>';
echo '<th>Operations</th></tr>';
$i = 1;
$qry = "SELECT author.author_id, author.full_name ,book.name, GROUP_CONCAT(book.name SEPARATOR ', ') AS books 
FROM author LEFT OUTER JOIN book ON author.author_id=book.author_id GROUP BY author.full_name";
$run = $db->select($qry);
foreach ($run as $row) {
    $id = $row['author_id'];
    echo '<tr><td>' . $i++ . '</td>';
    echo '<td>' . $row['author_id'] . '</td>';
    echo '<td> ' . $row['full_name'] . '</td>';
    echo '<td>' . $row['books'] . '</td>';
    echo '<td><a href="edit_author.php?id=' .$id. '" >Edit</a>';
    echo '<a href= "index.php?delete_author_id=' .$id. '"onclick="return confirm(\'Are you sure?\')">Delete</a>';
    echo '</td>';
    if (isset($_GET['delete_author_id'])) {
        $vysledek= $db->delete_author(filter_input(INPUT_GET,"delete_author_id", FILTER_SANITIZE_NUMBER_INT));
        if($vysledek == false){ 
            echo "Nastala chyba při mazání uživatele..."; 
        }
    }
    echo '</tr>';
}//select s buttony - book
echo '</table><br>';
echo '<h3>Listing of Books</h3>';
echo '<table>';
echo '<tr><th>N</th>';
echo '<th>b_id</th>';
echo '<th>Name</th>';
echo '<th>Published</th>';
echo '<th>Author</th>';
echo '<th>Operations</th></tr>';
$i = 1;
$qry = "SELECT book.book_id, book.publicing_year ,book.name, author.author_id, author.full_name
FROM book INNER JOIN author ON book.author_id=author.author_id GROUP BY book.name;";
$run = $db->select($qry);
foreach ($run as $row) {
    $id = $row['book_id'];
    echo '<tr><td>' . $i++ . '</td>';
    echo '<td>' . $row['book_id'] . '</td>';
    echo '<td>' . $row['name'] . '</td>';
    echo '<td>' . $row['publicing_year'] . '</td>';
    echo '<td>' . $row['full_name'] . '</td>';
    echo '<td>';
    echo '<a href="edit_book.php?id='.$id.'" >Edit</a>';
    echo '<a href="index.php?delete_book_id=' .$id. '" onclick="return confirm(\'Are you sure?\')">Delete</a>';
    echo '</td>';
    if (isset($_GET['delete_book_id'])) {
        $vysledek= $db->delete_book(filter_input(INPUT_GET,"delete_book_id", FILTER_SANITIZE_NUMBER_INT));
        if($vysledek == false){ 
            echo "Nastala chyba při mazání uživatele..."; 
        }
    }
    echo '</tr>';
}
echo '</table></td>';
    ?>
</body>
</html>
<?php
